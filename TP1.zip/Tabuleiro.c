#include "Tabuleiro.h"

Tabuleiro CriaTabuleiro(char NomeArquivo[]) //Cria o tabuleiro conforme o arquivo de texto
{
  Tabuleiro t; 
  FILE *arquivo = fopen (NomeArquivo, "r");
  for(int i = 0; i < 9; i++)
  {
    for(int j = 0; j < 9; j++)
      fscanf(arquivo, "%d", &t.Matriz[i][j]);
  }
  fclose(arquivo);
  return t;
}



Celula* defineVazias(Tabuleiro *t)//Descobre as coordenadas que estão com 0 
{
  int cont = 0;
  Celula *celulas = malloc(81 * sizeof(Celula));// aloca espaço para receber todas as coordenadas em um pior caso
  for(int i = 0; i < 9; i++)
  {
    for(int j = 0; j < 9; j++)
    {
      celulas[cont].linha = -1;
      celulas[cont].coluna = -1;
      if(t->Matriz[i][j] == 0)//caso seja 0  as celulas receberão as coordenadas 
      {
        celulas[cont].linha = i;
        celulas[cont].coluna = j;
        cont++;
      }
    }
  }
  return celulas;
}

bool Confere(Tabuleiro *puzzle,Celula c, int val){//Confere se um numero é valido para determinada posição
    int i, j;
    int linhabloco, colunabloco;

    //CHECK VERTICAL
    for(i = 0; i < 9; i++){
        if (puzzle->Matriz[i][c.coluna] == val)
            return false;
    }

    //CHECK HORIZONTAL
    for(j = 0; j < 9; j++){
        if (puzzle->Matriz[c.linha][j] == val)
            return false;
    }

    //CHECK QUADRADO
    linhabloco = c.linha - c.linha % 3;
    colunabloco = c.coluna - c.coluna % 3;

    for(i = 0; i < 3; i++){
        for(j = 0; j < 3; j++){
            if(puzzle->Matriz[linhabloco + i][colunabloco + j] == val)
                return false;
        }
    }

    return true;
}


void Resolver(Tabuleiro puzzle,Celula *c){ // Tenta resolver o Sudoku


  for (int i = 0; i < 81; i++)
  {
    for (int j = 1; j < 10; j++)
    {
       if (Confere(&puzzle,c[i],j))
       {
         InsereTabuleiro(&puzzle,j, c[i]);//Caso o numero seja valido ele será inserido no tabuleiro
       }
       
    }
    
  }
  
  printPuzzle(puzzle);//Imprime o tabuleiro 

}

void printPuzzle(Tabuleiro puzzle){//imprime o tabuleiro
    int i, j, a;

    printf("\n");
    printf(" 0 | 1  2  3 | 4  5  6 | 7  8  9 | Y\n");
    printf(" ---------------------------------\n");
    for (i = 0, a = 1; i < 9; i++, a++){
        for(j = 0; j < 9; j++){
            if (j == 0)
                printf(" %d |", a);
            else if ((j) % 3 == 0)
                printf("|");
            printf(" %d ", puzzle.Matriz[i][j]);
            if (j == 8)
                printf("|");
        }
        printf("\n");
        if ((i + 1) % 3 == 0)
            printf(" ---------------------------------\n");
    }
    printf(" X\n");
}



void InsereTabuleiro(Tabuleiro *t, int numero, Celula c)//insera número no tabuleiro
{
  t->Matriz[c.linha][c.coluna] = numero;
}

Celula EhValidoRegiao(Tabuleiro *t, Celula c) //Confere se a Região possui algum erro
{
  int item = t->Matriz[c.linha][c.coluna];
  Celula erro;
  erro.linha = -1;
  erro.coluna = -1;
  // Caso possua um erro retornará a coordenada, caso não será -1
  for(int linha = c.linha - c.linha % 3; linha < c.linha - c.linha % 3 +3; linha++)
  {
    for(int coluna = c.coluna - c.coluna % 3; coluna < c.coluna - c.coluna % 3 + 3; coluna++)
    {
      if(t->Matriz[linha][coluna] == item && linha != c.linha && coluna != c.coluna && t->Matriz[linha][coluna] != 0)
      {
        erro.linha = linha;
        erro.coluna = coluna;
      }
    }
  }
  return erro;
}

Celula EhValidoLinha(Tabuleiro *t, Celula c)// Confere se a linha possui algum erro
{ 
  int item = t->Matriz[c.linha][c.coluna];
  Celula erro;
  erro.linha = -1;
  erro.coluna = -1;
  for(int linha = 0; linha < 9; linha++){
    if(t->Matriz[linha][c.coluna] == item && c.linha != linha && t->Matriz[linha][c.coluna] != 0)
    {
      erro.linha = linha;
      erro.coluna = c.coluna;
    }
  }
  return erro;
}

Celula EhValidoColuna(Tabuleiro *t, Celula c)//confere se a coluna possui algum erro
{
  int item = t->Matriz[c.linha][c.coluna];
  Celula erro;
  erro.linha = -1;
  erro.coluna = -1;
  for(int coluna = 0; coluna < 9; coluna++){
    if(t->Matriz[c.linha][coluna] == item  && c.coluna != coluna && t->Matriz[c.linha][coluna] != 0)
    {
      erro.linha = c.linha;
      erro.coluna = coluna;
    }
  }
  return erro;
}

int EhValido(Tabuleiro *t, Celula c)// Usado para conferir se  o tabuleiro em si possui algum erro
{
  int flag = 1;
  Celula lin = EhValidoLinha(t, c);
  Celula col = EhValidoColuna(t, c);
  Celula reg = EhValidoRegiao(t, c); 
  if(lin.linha != -1 && lin.coluna != -1){
    flag = 0;
  }
  if(col.coluna != -1 && col.coluna != -1){
    flag = 0;
  }
  if(reg.linha != -1 && reg.coluna != -1){
    flag = 0;
  }
  return flag;
} 

int EhValidoTabuleiro(Tabuleiro *t)// Recebe todos os possiveis erros ou informa se o tabuleiro é valido
{
  Celula f;
  int flag = 1;
  for(f.linha = 0; f.linha < 9; f.linha++)
  {
    for(f.coluna = 0; f.coluna < 9; f.coluna++)
    {
      if(EhValido(t, f) == 0)
        flag = 0;
    }
  }
  return flag;
}

void NaoEhValidoTabuleiro(Tabuleiro *t)// Caso o tabuleiro não seja valido pegará as coordenadas dos erros e informará ao úsurario 
{
  Celula f, retorno;
  for(int i = 0; i < 9; i++)
  {
    for(int j = 0; j < 9; j++) 
    {
      f.linha = i;
      f.coluna = j;
      retorno = EhValidoLinha(t, f);
      if(retorno.linha != -1)
        printf ("Linha %d = (%d, %d) e (%d, %d)\n", i + 1, f.linha + 1, f.coluna + 1, retorno.linha + 1, retorno.coluna + 1);
    }
  }
  for(int i = 0; i < 9; i++)
  {
    for(int j = 0; j < 9; j++) 
    {
      f.linha = i;
      f.coluna = j;
      retorno = EhValidoColuna(t, f);
      if(retorno.linha != -1 && retorno.coluna != -1)
        printf ("Coluna %d = (%d, %d) e (%d, %d)\n", j + 1, f.linha + 1, f.coluna + 1, retorno.linha + 1, retorno.coluna + 1);
    }
  }
  int regiao;
  for(int i = 0; i < 9; i++)
  {
    for(int j = 0; j < 9; j++) 
    {
      f.linha = i;
      f.coluna = j;
      retorno = EhValidoColuna(t, f);

      if (retorno.linha != -1){
        if (i < 3){
          if (j < 3){
            regiao = 1;
          }else if (j < 6){
            regiao = 2;
          }
          else{
            regiao = 3;
          }
        }else if (i < 6){
          if (j < 3){
            regiao = 4;
          }else if (j < 6){
            regiao = 5;
          }
          else{
            regiao = 6;
          }
        }else{
          if (j < 3){
            regiao = 7;
          }else if (j < 6){
            regiao = 8;
          }
          else{
            regiao = 9;
          }
        }
        printf ("Regiao %d = (%d, %d) e (%d, %d)\n", regiao, f.linha + 1, f.coluna + 1, retorno.linha + 1, retorno.coluna + 1);
      }
    }
  }
}

void Dicas(Tabuleiro *t, Celula *celulas) // Caso não possua erros serão fornecidas dicas de jogas possiveis
{
  int cont = 0;
  while(celulas[cont].linha != -1)
  {
    printf("(%d, %d): ", celulas[cont].linha + 1, celulas[cont].coluna + 1);
    for(int i = 1; i <= 9; i++)
    {
      InsereTabuleiro(t, i, celulas[cont]);
      if(EhValido(t, celulas[cont]) == 1)
      {
        printf("%d ", i);
      }
    }
    printf("\n");
    InsereTabuleiro(t, 0, celulas[cont]);
    cont++;
  }
}