#include <stdio.h>
#include "Tabuleiro.h"

// Compilação 
// gcc Tabuleiro.c -c
// gcc Tabuleiro.o main.c -o exe
// gcc *.c -o exe -Wall
// ./exe tabuleiro.txt
int main(int argc, char *argv[])//Recebe o nome do arquivo 
{
  if (argc < 2) 
  {
    printf ("Uso : %s <arquivo_tabuleiro >\n", argv [0]) ;
    return 0;
  }
  
  Tabuleiro t = CriaTabuleiro(argv[1]); //t recebe o tabuleiro criado apartir do nome do arquivo 
  printPuzzle(t);//imprime o tabuleiro

 
  int x;//recebe 1 para verificar e 2 para tentar resolver
  printf("Verificar(1) ou Resolver(2):");
  scanf("%d",&x);
  Celula *celulas = defineVazias(&t);// o vetor recebe todas as coordenadas que estão com espaços vazios 
  if (x == 1)
  {
    int erro = EhValidoTabuleiro (&t);//erro recebe o codigo informando que tem  ou não tem erros no tabuleiro
    if(erro == 1 && celulas[0].linha != -1)//caso não tenha erros e ainda tenha espaços vazios
    {
      //valido
      printf("Voce esta no caminho certo. Sugestoes: \n");
      Dicas(&t, celulas);
    }
    else if(erro == 1 && celulas[0].linha == -1)//caso não tenha erros e nem espaços vazios
      printf("Parabens, Jogo Completo. \n");
    else//caso tenha erros
    {
      printf("Alguma coisa deu errado... Invalidos: \n");
      NaoEhValidoTabuleiro(&t);
    }
  }
  
  else{//caso o usuario digite 2 sera direcionado para a resolução do Sudoku
    getchar();
    Resolver(t,celulas);
    
  }

  free(celulas);
  return 0;
}