#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct{ //struct que sera usada para compor as coordenadas 
  int linha;
  int coluna;
} Celula;


typedef struct{//struct para receber o Sudoku
  int Matriz[9][9];
} Tabuleiro;

Tabuleiro CriaTabuleiro(char *NomeArquivo);

Celula* defineVazias(Tabuleiro *t);

void Resolver(Tabuleiro puzzle,Celula *c);

bool Confere(Tabuleiro *puzzle,Celula c, int val);

void printPuzzle(Tabuleiro puzzle);

void InsereTabuleiro(Tabuleiro *t, int numero, Celula c);

int EhValido(Tabuleiro *t, Celula c);

Celula EhValidoColuna(Tabuleiro *t, Celula c);

Celula EhValidoLinha(Tabuleiro *t, Celula c);

Celula EhValidoRegiao(Tabuleiro *t, Celula c);

int EhValidoTabuleiro(Tabuleiro *t);

void NaoEhValidoTabuleiro(Tabuleiro *t);

void Dicas(Tabuleiro *t, Celula *celulas);